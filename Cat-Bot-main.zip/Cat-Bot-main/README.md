

<center>
  <a href="https://youtube.com/@clovermods">
    <img src="https://telegra.ph/file/41598dec8462fb039c130.jpg" width="610">
  </a>
</center>

# Clover V6
@clovermods yt

# Como Instalar o Bot
1. COMANDO:

```
termux-setup-storage && pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install git -y && pkg install ffmpeg -y && pkg install yarn
```

2. COMANDO:

```
cd /sdcard && git clone https://github.com/trevo-community/Cat-Bot && cd Cat-Bot && yarn install
```

3. COMANDO:

```
sh start.sh
```
ou
```
node index.js
```

• Depois só colocar seu numero 
